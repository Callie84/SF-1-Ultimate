import type { Metadata } from 'next';
import { StrainDetailClient } from './strain-detail-client';

export async function generateMetadata(
  { params }: { params: { slug: string } }
): Promise<Metadata> {
  try {
    const communityServiceUrl =
      process.env.COMMUNITY_SERVICE_URL || 'http://community-service:3005';
    const res = await fetch(
      `${communityServiceUrl}/api/community/strains/${params.slug}`,
      { next: { revalidate: 3600 } }
    );
    if (res.ok) {
      const strain = await res.json();
      const title = `${strain.name} — Cannabis Strain`;
      const desc = strain.description
        ? strain.description.slice(0, 155)
        : `${strain.name} — Typ: ${strain.type}. THC: ${strain.thc ?? '–'}%, CBD: ${strain.cbd ?? '–'}%. Jetzt Preise vergleichen auf SeedFinderPro.`;
      return {
        title,
        description: desc,
        openGraph: {
          title,
          description: desc,
          images: strain.imageUrl ? [{ url: strain.imageUrl }] : [],
        },
      };
    }
  } catch {}
  return { title: 'Strain Details' };
}

export default function StrainDetailPage({ params }: { params: { slug: string } }) {
  return <StrainDetailClient slug={params.slug} />;
}
