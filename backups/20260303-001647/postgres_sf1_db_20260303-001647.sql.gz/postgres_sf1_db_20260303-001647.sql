--
-- PostgreSQL database dump
--

\restrict Gn14ckm0Zl1CzivIk4DQatpjmCdpfrbQdTEqv88AWETG2DTylrdiZYE7uNKd7pv

-- Dumped from database version 15.14
-- Dumped by pg_dump version 15.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: AuthProvider; Type: TYPE; Schema: public; Owner: sf1_user
--

CREATE TYPE public."AuthProvider" AS ENUM (
    'LOCAL',
    'GOOGLE',
    'DISCORD'
);


ALTER TYPE public."AuthProvider" OWNER TO sf1_user;

--
-- Name: UserRole; Type: TYPE; Schema: public; Owner: sf1_user
--

CREATE TYPE public."UserRole" AS ENUM (
    'USER',
    'PREMIUM',
    'MODERATOR',
    'ADMIN'
);


ALTER TYPE public."UserRole" OWNER TO sf1_user;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: PasswordReset; Type: TABLE; Schema: public; Owner: sf1_user
--

CREATE TABLE public."PasswordReset" (
    id text NOT NULL,
    email text NOT NULL,
    token text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    used boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."PasswordReset" OWNER TO sf1_user;

--
-- Name: RefreshToken; Type: TABLE; Schema: public; Owner: sf1_user
--

CREATE TABLE public."RefreshToken" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    family text NOT NULL,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."RefreshToken" OWNER TO sf1_user;

--
-- Name: Session; Type: TABLE; Schema: public; Owner: sf1_user
--

CREATE TABLE public."Session" (
    id text NOT NULL,
    "userId" text NOT NULL,
    token text NOT NULL,
    "ipAddress" text,
    "userAgent" text,
    "expiresAt" timestamp(3) without time zone NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL
);


ALTER TABLE public."Session" OWNER TO sf1_user;

--
-- Name: User; Type: TABLE; Schema: public; Owner: sf1_user
--

CREATE TABLE public."User" (
    id text NOT NULL,
    email text NOT NULL,
    username text,
    "passwordHash" text,
    role public."UserRole" DEFAULT 'USER'::public."UserRole" NOT NULL,
    provider public."AuthProvider" DEFAULT 'LOCAL'::public."AuthProvider" NOT NULL,
    "providerId" text,
    "premiumUntil" timestamp(3) without time zone,
    avatar text,
    bio text,
    "isVerified" boolean DEFAULT false NOT NULL,
    "isActive" boolean DEFAULT true NOT NULL,
    "isBanned" boolean DEFAULT false NOT NULL,
    "createdAt" timestamp(3) without time zone DEFAULT CURRENT_TIMESTAMP NOT NULL,
    "updatedAt" timestamp(3) without time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO sf1_user;

--
-- Data for Name: PasswordReset; Type: TABLE DATA; Schema: public; Owner: sf1_user
--

COPY public."PasswordReset" (id, email, token, "expiresAt", used, "createdAt") FROM stdin;
\.


--
-- Data for Name: RefreshToken; Type: TABLE DATA; Schema: public; Owner: sf1_user
--

COPY public."RefreshToken" (id, "userId", token, family, "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: Session; Type: TABLE DATA; Schema: public; Owner: sf1_user
--

COPY public."Session" (id, "userId", token, "ipAddress", "userAgent", "expiresAt", "createdAt") FROM stdin;
\.


--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: sf1_user
--

COPY public."User" (id, email, username, "passwordHash", role, provider, "providerId", "premiumUntil", avatar, bio, "isVerified", "isActive", "isBanned", "createdAt", "updatedAt") FROM stdin;
cmlhdcc5q00018nmfqk8qw6uk	admin@gmail.com	admin	$argon2id$v=19$m=65536,t=3,p=4$bkLv3BPmVI0FXgoDyu9eGg$B+9t9L/xDAJB1o2J6FdXgag7OlQ7pBTQxUlWDPD/L+0	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-02-11 01:46:14.798	2026-02-17 15:06:29.503
cml5jeqak000212gjc5udgkhn	klingenpascal@gmail.com	klingenpascal	$argon2id$v=19$m=65536,t=3,p=4$qqiStusMDR2cRgEeT98KQg$DpdYABmZ0pFnzp2bHrFGDb0cYC2rpr2ZvyKde2N/hGo	ADMIN	LOCAL	\N	\N	\N	\N	f	t	f	2026-02-02 19:02:50.012	2026-02-23 19:00:57.866
cmm9gj5fn0000wyzar2q6adnb	test@seedfinderpro.de	testuser	$argon2id$v=19$m=65536,t=3,p=4$JfEH6Forkrexl+Un41+XDg$KuO9xMWZw3+MkDR3PANRQv8NwTJ9V3rmtDcoYuO1nNM	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-03-02 17:33:04.451	2026-03-02 17:34:47.47
cmkzmikca000012gj737psk0l	new@test.de	Test	$argon2id$v=19$m=65536,t=3,p=4$ndYp/dOAdTHdK6hEyjzMJA$HcwM55Vks56+JzOwHLuwTyxf+b2rFtyPIFyWRlwi+qQ	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-01-29 15:43:10.714	2026-01-29 15:43:10.714
cmkzjb0hi00008ckkwv9762zd	admin@sf1.local	Administrator	$argon2id$v=19$m=65536,t=3,p=4$O2YLAU2FZW4v4FS9A8PMiQ$ING8ft9jkzsdF45IgsWPP9ankW/NFrlZieOdFQWrRnw	ADMIN	LOCAL	\N	\N	\N	\N	f	t	f	2026-01-29 14:13:19.543	2026-01-29 22:15:30.008
cml5hlmkq000112gjtpehow02	simpletest@example.com	simpletest	$argon2id$v=19$m=65536,t=3,p=4$vIrh65Mx50ahqGvbLNTX9g$Xnt0nwZxQIO0lV7Ok7RwCWP43WQRpx6tc8GH8g8PS3w	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-02-02 18:12:12.553	2026-02-02 18:12:31.446
cmm9gxhhe0001wyzawpmrzqoo	testlogin@test.de	testlogin	$argon2id$v=19$m=65536,t=3,p=4$q/iKkFWVnwWA446wzyuq0Q$0s81hif4f1rzffv32XHo2jn3wiFbMsu1+7Qg3kDyd2c	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-03-02 17:44:13.25	2026-03-02 17:44:13.301
cmm9hej760002wyzan24jfd6m	journal-test@test.de	journaltest	$argon2id$v=19$m=65536,t=3,p=4$4ZTvkTradUV2NmidfCew7g$g307uYSzRpJvTRNXdcb+S7oh/G6O/1NM9h8KrwOPwNU	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-03-02 17:57:28.626	2026-03-02 17:57:28.626
cmm9heu2o0003wyzauefo42x5	journaltest2@test.de	journaltest2	$argon2id$v=19$m=65536,t=3,p=4$7/vs0vkEbFcy3Ud8SeLxHw$f1VtrrD9pS8Hr8jurmDSuvYrpf1nGvrMz2MST64fgTM	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-03-02 17:57:42.72	2026-03-02 17:57:42.72
cmlhbmh3000005vww2x9dwrik	testcurl@test.de	testcurl	$argon2id$v=19$m=65536,t=3,p=4$AchDXBJBM7/lJsO/q4KgCQ$uvLQHajmv60CAoZM2bPJdPDZVLWaRR15G7DQeLWJdqs	USER	LOCAL	\N	\N	\N	\N	f	t	f	2026-02-11 00:58:08.508	2026-02-11 00:58:08.508
\.


--
-- Name: PasswordReset PasswordReset_pkey; Type: CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."PasswordReset"
    ADD CONSTRAINT "PasswordReset_pkey" PRIMARY KEY (id);


--
-- Name: RefreshToken RefreshToken_pkey; Type: CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_pkey" PRIMARY KEY (id);


--
-- Name: Session Session_pkey; Type: CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: PasswordReset_email_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "PasswordReset_email_idx" ON public."PasswordReset" USING btree (email);


--
-- Name: PasswordReset_token_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "PasswordReset_token_idx" ON public."PasswordReset" USING btree (token);


--
-- Name: PasswordReset_token_key; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE UNIQUE INDEX "PasswordReset_token_key" ON public."PasswordReset" USING btree (token);


--
-- Name: RefreshToken_family_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "RefreshToken_family_idx" ON public."RefreshToken" USING btree (family);


--
-- Name: RefreshToken_token_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "RefreshToken_token_idx" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_token_key; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE UNIQUE INDEX "RefreshToken_token_key" ON public."RefreshToken" USING btree (token);


--
-- Name: RefreshToken_userId_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "RefreshToken_userId_idx" ON public."RefreshToken" USING btree ("userId");


--
-- Name: Session_expiresAt_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "Session_expiresAt_idx" ON public."Session" USING btree ("expiresAt");


--
-- Name: Session_token_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "Session_token_idx" ON public."Session" USING btree (token);


--
-- Name: Session_token_key; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE UNIQUE INDEX "Session_token_key" ON public."Session" USING btree (token);


--
-- Name: Session_userId_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "Session_userId_idx" ON public."Session" USING btree ("userId");


--
-- Name: User_email_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "User_email_idx" ON public."User" USING btree (email);


--
-- Name: User_email_key; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE UNIQUE INDEX "User_email_key" ON public."User" USING btree (email);


--
-- Name: User_username_idx; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE INDEX "User_username_idx" ON public."User" USING btree (username);


--
-- Name: User_username_key; Type: INDEX; Schema: public; Owner: sf1_user
--

CREATE UNIQUE INDEX "User_username_key" ON public."User" USING btree (username);


--
-- Name: RefreshToken RefreshToken_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."RefreshToken"
    ADD CONSTRAINT "RefreshToken_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Session Session_userId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: sf1_user
--

ALTER TABLE ONLY public."Session"
    ADD CONSTRAINT "Session_userId_fkey" FOREIGN KEY ("userId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict Gn14ckm0Zl1CzivIk4DQatpjmCdpfrbQdTEqv88AWETG2DTylrdiZYE7uNKd7pv

